package practice3;

public class teacher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
